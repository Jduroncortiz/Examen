public class VIPTicket 
{
     // Your code goes here.   
}
